package com.belajar.andro.mayur;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

import com.bumptech.glide.Glide;

public class DetailActivity extends AppCompatActivity {

    private Vegetable getVegetable;
    private ImageView imgPhoto;
    private TextView tvName, tvAdvantage;

    public static final String DETAIL_VEGETABLE = "Vegetable";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        getVegetable = getIntent().getParcelableExtra(DETAIL_VEGETABLE);

        imgPhoto = findViewById(R.id.detail_image);

        Glide.with(getApplicationContext())
                .load(getVegetable.getImage())
                .into(imgPhoto);

        tvName = findViewById(R.id.detail_name);
        tvName.setText(getVegetable.getName());
        tvAdvantage = findViewById(R.id.detail_advantage);
        tvAdvantage.setText(getVegetable.getAdvantage());

    }
}
