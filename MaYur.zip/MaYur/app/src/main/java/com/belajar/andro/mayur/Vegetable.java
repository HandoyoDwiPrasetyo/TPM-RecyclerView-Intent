package com.belajar.andro.mayur;

import android.os.Parcel;
import android.os.Parcelable;

public class Vegetable implements Parcelable {
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    private String name;

    public String getAdvantage() {
        return advantage;
    }

    public void setAdvantage(String advantage) {
        this.advantage = advantage;
    }

    private String advantage;

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    private String image;

    public String getVitamin(){
        return vitamin;
    }

    public void setVitamin(String vitamin){
        this.vitamin = vitamin;
    }

    private String vitamin;


    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(this.name);
        dest.writeString(this.advantage);
        dest.writeString(this.image);
        dest.writeString(this.vitamin);
    }

    public Vegetable() {
    }

    protected Vegetable(Parcel in) {
        this.name = in.readString();
        this.advantage = in.readString();
        this.image = in.readString();
        this.vitamin = in.readString();
    }

    public static final Parcelable.Creator<Vegetable> CREATOR = new Parcelable.Creator<Vegetable>() {
        @Override
        public Vegetable createFromParcel(Parcel source) {
            return new Vegetable(source);
        }

        @Override
        public Vegetable[] newArray(int size) {
            return new Vegetable[size];
        }
    };
}
