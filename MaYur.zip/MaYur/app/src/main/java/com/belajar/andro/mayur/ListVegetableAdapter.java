package com.belajar.andro.mayur;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.bumptech.glide.Glide;
import com.bumptech.glide.request.RequestOptions;

import java.util.ArrayList;

public class ListVegetableAdapter extends RecyclerView.Adapter<ListVegetableAdapter.ListViewHolder> {
    private ArrayList<Vegetable> listVegetable;
    private Context context;

    public ListVegetableAdapter(Context context) {
        this.context = context;
    }

    public void listVegetableItem(ArrayList<Vegetable> list){
        this.listVegetable = list;
    }

    @NonNull
    @Override
    public ListVegetableAdapter.ListViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int viewType) {
        View view = LayoutInflater.from(viewGroup.getContext()).inflate(R.layout.item_row_vegetable, viewGroup, false);
        return new ListViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull final ListVegetableAdapter.ListViewHolder holder, int position) {
        final Vegetable vegetable = listVegetable.get(position);

        Glide.with(holder.itemView.getContext())
                .load(vegetable.getImage())
                .apply(new RequestOptions().override(55, 55))
                .into(holder.imgPhoto);

        holder.tvName.setText(vegetable.getName());
        holder.tvVitamin.setText(vegetable.getVitamin());

        holder.itemVegetable.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent moveIntent = new Intent(context, DetailActivity.class);

                Vegetable v = new Vegetable();
                v.setImage(vegetable.getImage());
                v.setName(vegetable.getName());
                v.setAdvantage(vegetable.getAdvantage());

                moveIntent.putExtra("Vegetable",v);
                context.startActivity(moveIntent);
            }
        });
    }

    @Override
    public int getItemCount() {
        return listVegetable.size();
    }

    public class ListViewHolder extends RecyclerView.ViewHolder {
        ImageView imgPhoto;
        TextView tvName, tvVitamin;
        RelativeLayout itemVegetable;
        public ListViewHolder(@NonNull View itemView) {
            super(itemView);
            imgPhoto = itemView.findViewById(R.id.img_item_photo);
            tvName = itemView.findViewById(R.id.tv_item_name);
            tvVitamin = itemView.findViewById(R.id.tv_item_vitamin);

            itemVegetable = itemView.findViewById(R.id.item_vegetable);
        }
    }
}
